<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Services\MidtransService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

class PaymentController extends Controller
{
    protected $midtransService;

    public function __construct(MidtransService $midtransService)
    {
        $this->midtransService = $midtransService;
    }

    /**
     * Membuat token pembayaran untuk order
     */
    public function createPayment(Order $order)
    {
        // Pastikan user hanya bisa bayar order miliknya sendiri
        if ($order->user_id !== Auth::id()) {
            return response()->json(['error' => 'Tidak diizinkan'], 403);
        }

        // Cek apakah order bisa dibayar
        if ($order->payment_status !== 'pending') {
            return response()->json(['error' => 'Order tidak dapat dibayar'], 400);
        }

        try {
            $transaction = $this->midtransService->createTransaction($order);

            return response()->json([
                'snap_token' => $transaction->token,
                'redirect_url' => $transaction->redirect_url
            ]);
        } catch (\Exception $e) {
            Log::error('Gagal membuat pembayaran Midtrans: ' . $e->getMessage());
            return response()->json(['error' => 'Gagal membuat pembayaran'], 500);
        }
    }

    /**
     * Handle notifikasi dari Midtrans
     */
    public function notification(Request $request)
    {
        try {
            $notification = $request->all();

            $orderId = $notification['order_id'];
            $transactionStatus = $notification['transaction_status'];
            $fraudStatus = $notification['fraud_status'] ?? '';

            Log::info('Notifikasi Midtrans diterima', $notification);

            // Cari order berdasarkan midtrans_order_id
            $order = Order::where('midtrans_order_id', $orderId)->first();

            if (!$order) {
                Log::error('Order tidak ditemukan untuk Midtrans order ID: ' . $orderId);
                return response('Order tidak ditemukan', 404);
            }

            DB::beginTransaction();

            // Update status pembayaran berdasarkan status transaksi
            switch ($transactionStatus) {
                case 'capture':
                    if ($fraudStatus == 'challenge') {
                        $order->update(['payment_status' => 'pending']);
                    } else if ($fraudStatus == 'accept') {
                        $order->update(['payment_status' => 'paid']);
                    }
                    break;

                case 'settlement':
                    $order->update(['payment_status' => 'paid']);
                    break;

                case 'pending':
                    $order->update(['payment_status' => 'pending']);
                    break;

                case 'deny':
                case 'expire':
                case 'cancel':
                    $order->update(['payment_status' => 'failed']);
                    break;
            }

            DB::commit();

            return response('OK', 200);
        } catch (\Exception $e) {
            DB::rollBack();
            Log::error('Gagal menangani notifikasi Midtrans: ' . $e->getMessage());
            return response('Error', 500);
        }
    }

    /**
     * Handle pembayaran selesai dengan sukses
     */
    public function finish(Request $request)
    {
        $orderId = $request->get('order_id');

        if ($orderId) {
            $order = Order::where('midtrans_order_id', $orderId)->first();

            if ($order && $order->user_id === Auth::id()) {
                return redirect()->route('member.orders.status')
                    ->with('success', 'Pembayaran berhasil! Pesanan Anda sedang diproses.');
            }
        }

        return redirect()->route('member.orders.status')
            ->with('info', 'Status pembayaran sedang diverifikasi.');
    }

    /**
     * Handle pembayaran yang belum selesai
     */
    public function unfinish(Request $request)
    {
        return redirect()->route('member.orders.status')
            ->with('warning', 'Pembayaran belum selesai. Silakan lanjutkan pembayaran.');
    }

    /**
     * Handle error pembayaran
     */
    public function error(Request $request)
    {
        return redirect()->route('member.orders.status')
            ->with('error', 'Terjadi kesalahan dalam proses pembayaran. Silakan coba lagi.');
    }

    /**
     * Cek status pembayaran
     */
    public function checkStatus(Order $order)
    {
        // Pastikan user hanya bisa cek order miliknya sendiri
        if ($order->user_id !== Auth::id()) {
            return response()->json(['error' => 'Tidak diizinkan'], 403);
        }

        try {
            $status = $this->midtransService->getTransactionStatus($order->midtrans_order_id);

            return response()->json([
                'transaction_status' => $status->transaction_status ?? '',
                'payment_type' => $status->payment_type ?? '',
                'transaction_time' => $status->transaction_time ?? '',
            ]);
        } catch (\Exception $e) {
            Log::error('Gagal mengecek status pembayaran: ' . $e->getMessage());
            return response()->json(['error' => 'Gagal mengecek status'], 500);
        }
    }
}
