<?php

namespace App\Services;

use Midtrans\Config;
use Midtrans\Snap;
use Midtrans\Transaction;

class MidtransService
{
    public function __construct()
    {
        // Konfigurasi Midtrans
        Config::$serverKey = config('midtrans.server_key');
        Config::$isProduction = config('midtrans.is_production');
        Config::$isSanitized = config('midtrans.is_sanitized');
        Config::$is3ds = config('midtrans.is_3ds');
    }

    /**
     * Membuat transaksi pembayaran
     */
    public function createTransaction($order)
    {
        $params = [
            'transaction_details' => [
                'order_id' => $order->midtrans_order_id,
                'gross_amount' => (int) $order->total_price,
            ],
            'customer_details' => [
                'first_name' => $order->user->name,
                'email' => $order->user->email,
                'phone' => $order->user->phone ?? '08123456789',
            ],
            'item_details' => [
                [
                    'id' => $order->service->id,
                    'price' => (int) $order->total_price,
                    'quantity' => 1,
                    'name' => $order->service->name,
                ]
            ],
            'callbacks' => [
                'finish' => route('member.payment.finish'),
                'unfinish' => route('member.payment.unfinish'),
                'error' => route('member.payment.error'),
            ]
        ];

        return Snap::createTransaction($params);
    }

    /**
     * Mengecek status transaksi
     */
    public function getTransactionStatus($orderId)
    {
        return Transaction::status($orderId);
    }
}
